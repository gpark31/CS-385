/*******************************************************************************
 * Name        : shortestpaths.cpp
 * Author      : Luca Pieples, GaYoung Park
 * Date        : December 7, 2020
 * Description : Solve the all pairs shortest paths problem with Floyd’s algorithm.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/

#include <iostream>
#include <sstream>
#include <string.h>
#include <stdio.h>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <vector>
#include <iomanip>

using namespace std;

int num_vertices;
vector<vector<long>> distMatrix, pathMatrix, intermediateMatrix;

/**
* Displays the matrix on the screen formatted as a table.
*/
int len(long num) {
	int digits = 1;
	while(num >= 10) {
		num = num / 10;
		digits++;
	}
    return digits;
}

void display_table(vector<vector<long>> matrix, string &label, const bool use_letters = false) {
	cout << label << endl;
	long max_val = 0;
	for (int i = 0; i < num_vertices; i++) {
		for (int j = 0; j < num_vertices; j++) {
			long cell = matrix[i][j];
			if (cell != -1 && cell > max_val) {
				max_val = matrix[i][j];
			}
		}
	}
	int max_cell_width = use_letters ? len(max_val) :
	len(max(static_cast<long>(num_vertices), max_val));
	cout << ' ';
	for (int j = 0; j < num_vertices; j++) {
		cout << setw(max_cell_width + 1) << static_cast<char>(j + 'A');
	}
	cout << endl;
	for (int i = 0; i < num_vertices; i++) {
		cout << static_cast<char>(i + 'A');
		for (int j = 0; j < num_vertices; j++) {
			cout << " " << setw(max_cell_width);
			if (matrix[i][j] == -1) {
				cout << "-";
			} else if (use_letters) {
				cout << static_cast<char>(matrix[i][j] + 'A');
			} else {
				cout << matrix[i][j];
			}
		}
		cout << endl;
	 }
	 cout << endl;
}

void floyd(vector<vector<long>> matrix) {
	pathMatrix = matrix;
	for(int k = 0; k<num_vertices; k++) {
		for(int i = 0; i<num_vertices; i++) {
			for(int j = 0; j<num_vertices; j++) {
				if(pathMatrix[i][j] == -1 && (pathMatrix[i][k] == -1 || pathMatrix[k][j] == -1)) {
					pathMatrix[i][j] = -1;
				}
				else if(pathMatrix[i][j] == -1) {
					pathMatrix[i][j] = pathMatrix[i][k] + pathMatrix[k][j];
					intermediateMatrix[i][j] = k;
				}
				else if(pathMatrix[i][k] == -1 || pathMatrix[k][j] == -1) {
					//do nothing
				}
				else {
					if(pathMatrix[i][k] + pathMatrix[k][j] < pathMatrix[i][j]) {
						intermediateMatrix[i][j] = k;
					}
					pathMatrix[i][j] = min(pathMatrix[i][j], pathMatrix[i][k] + pathMatrix[k][j]);
				}
			}
		}
	}
}

string pathFind(int i, int j) {
	if(i == j) {
		stringstream ss;
		ss << static_cast<char>(i + 'A');
		return ss.str();
	}
	else if(intermediateMatrix[i][j] == -1) {
		stringstream ss;
		ss << static_cast<char>(i + 'A') << " -> " << static_cast<char>(j + 'A');
		return ss.str();
	}
	else {
		stringstream ss;
		ss << pathFind(i, intermediateMatrix[i][j]) << " -> " << pathFind(intermediateMatrix[i][j], j).substr(5);
		return ss.str();
	}
}

void display_paths() {
	for(int i = 0; i < num_vertices; i++) {
		for(int j = 0; j < num_vertices; j++) {
			if(pathMatrix[i][j] == -1) {
				cout << static_cast<char>(i + 'A') << " -> " << static_cast<char>(j + 'A') << ", distance: infinity, path: none" << endl;
			}
			else {
				cout << static_cast<char>(i + 'A') << " -> " << static_cast<char>(j + 'A') << ", distance: " << pathMatrix[i][j] << ", path: " << pathFind(i, j) << endl;
			}
		}
	}
}

int main(int argc, const char *argv[]) {
    // Make sure the right number of command line arguments exist.
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <filename>" << endl;
        return 1;
    }
    // Create an ifstream object.
    ifstream input_file(argv[1]);
    // If it does not exist, print an error message.
    if (!input_file) {
        cerr << "Error: Cannot open file '" << argv[1] << "'." << endl;
        return 1;
    }
    // Add read errors to the list of exceptions the ifstream will handle.
    input_file.exceptions(ifstream::badbit);
    string line;
    try {
        unsigned int line_number = 1;
        // Use getline to read in a line.
        // See http://www.cplusplus.com/reference/string/string/getline/
        while (getline(input_file, line)) {
        	//Case 1: line 1 must be between 1 and 26
        	istringstream iss(line);
            if(line_number == 1){
				if ( !(iss >> num_vertices) ) {
					cerr << "Error: Invalid number of vertices '" << line << "' on line 1.";
					return 1;
				}
            	if(num_vertices > 26 || num_vertices <= 0) {
            		cerr << "Error: Invalid number of vertices '" << num_vertices << "' on line 1.";
            		return 1;
            	}
            	vector<long> sub;
            	for(int i = 0; i < num_vertices; i++) {
            		sub.push_back(-1);
            	}
            	for(int j = 0; j < num_vertices; j++) {
        			distMatrix.push_back(sub);
        		}
            	for(int i = 0; i < num_vertices; i++) {
					for(int j = 0; j < num_vertices; j++) {
						if(i == j) {
							distMatrix[i][j] = 0;
						}
					}
				}
            }
            else {
				string s1, s2;
				int weight;
				char valid_values = 'A' + num_vertices - 1;
				char c1, c2;
				if(line.length() < 5) {
					cerr << "Error: Invalid edge data '" << line << "' on line " << line_number << ".";
					return 1;
				}
				if(!(iss >> s1) || s1.length() > 1) {
					cerr << "Error: Starting vertex '" << s1 << "' on line " << line_number << " is not among valid values A-" << valid_values << ".";
					return 1;
				}
				else {
					c1 = s1.c_str()[0];
					if(c1 < 'A' || c1 > valid_values) {
						cerr << "Error: Starting vertex '" << s1 << "' on line " << line_number << " is not among valid values A-" << valid_values << ".";
						return 1;
					}
				}
				if(!(iss >> s2) || s2.length() > 1) {
					cerr << "Error: Ending vertex '" << s2 << "' on line " << line_number << " is not among valid values A-" << valid_values << ".";
					return 1;
				}
				else {
					c2 = s2.c_str()[0];
					if(c2 < 'A' || c2 > valid_values) {
						cerr << "Error: Ending vertex '" << s2 << "' on line " << line_number << " is not among valid values A-" << valid_values << ".";
						return 1;
					}
				}
				if ( !(iss >> weight) || weight <= 0) {
					cerr << "Error: Invalid edge weight '" << line.substr(4) << "' on line " << line_number << ".";
					return 1;
				}
				int x = c1 - 'A';
				int y = c2 - 'A';
				distMatrix[x][y] = weight;
			}
            ++line_number;
        }
        // Don't forget to close the file.
        input_file.close();
    } catch (const ifstream::failure &f) {
        cerr << "Error: An I/O error occurred reading '" << argv[1] << "'.";
        return 1;
    }

	vector<long> sub;
	for(int i = 0; i < num_vertices; i++) {
		sub.push_back(-1);
	}
	for(int j = 0; j < num_vertices; j++) {
		intermediateMatrix.push_back(sub);
	}

	floyd(distMatrix);

    string str1 = "Distance matrix:";
    display_table(distMatrix, str1);
    string str2 = "Path lengths:";
    display_table(pathMatrix, str2);
    string str3 = "Intermediate vertices:";
    display_table(intermediateMatrix, str3, true);
    display_paths();
    return 0;
}
