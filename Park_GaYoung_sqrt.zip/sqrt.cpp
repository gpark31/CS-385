/*
 * sqrt.cpp
 *
 *  Created on: Sep 2, 2020
 *      Author: GaYoung Park
 *      I pledge my honor that I have abided by the Stevens Honor System.
 */
using namespace std;

#include <iostream>
#include <limits>
#include <iomanip>
#include <sstream>
//compute the square root of a double using Newton's method.

double sqrt(double num, double epsilon){
	double next_guess;
	double last_guess = num;

	if(num < 0.0){
		return numeric_limits<double>::quiet_NaN();
	}
	if(num == 0.0 || num ==1.0){
		return num;
	}
	next_guess = (last_guess + num/last_guess)/2.0;
	while(abs(last_guess-next_guess) > epsilon){
		double temp = next_guess;
		last_guess = temp;
		next_guess = (last_guess + num/last_guess)/2.0;
	}
	return next_guess;
}

int main(int argc, char *argv[]){
	double m, n;
	istringstream iss;
	if(argc <= 1 || argc > 3){
		cerr << "Usage: " << argv[0] << " <value> [epsilon]" << endl;
		return 1;
	}
	iss.str(argv[1]);
	if(!(iss >> m)){
		cerr << "Error: Value argument must be a double." << endl;
		return 1;
	}
	if(argc < 3){
		n = 1e-7;
	}
	else{
		iss.clear();
		iss.str(argv[2]);
		if(!(iss >> n)){
			cerr << "Error: Epsilon argument must be a positive double." << endl;
			return 1;
		}
		if(n <= 0.0){
			cout << "Error: Epsilon argument must be a positive double." << endl;
			return 1;
		}
	}

	cout << fixed << setprecision(8) << sqrt(m, n) << endl;
	return 0;
}




