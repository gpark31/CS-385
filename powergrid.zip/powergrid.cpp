/*******************************************************************************
 * Name        : shortestpaths.cpp
 * Author      : GaYoung Park
 * Date        : December 16, 2020
 * Description : find the shortest path between streets
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/

#include <iostream>
#include <sstream>
#include <string.h>
#include <stdio.h>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <vector>
#include <iomanip>
#include <map>
#include <bits/stdc++.h>
#include <utility>
using namespace std;

string num_vertices;
vector<vector<int>> edges;
map<string, string> MAP;
int num_v;

bool sortMap(pair<string, int>& a, pair<string, int>& b)
{
    return a.second < b.second;
}

void sort(map<string, int>& M) {
    vector<pair<string, int> > vec;
    for (auto& it : M) {
        vec.push_back(it);
    }
    sort(vec.begin(), vec.end(), sortMap);
}

bool is_path(){
	int test1 = -1;
	vector<int> vec;
	for(unsigned long int i = 0; i < edges.size(); i++){
		for(unsigned long int j = 0; j <= i; j++){
			if(edges[i][j] != -1){
				test1 = edges[i][j];
				break;
			}
		}
		if(test1 == -1){
			vec.push_back(i);
		}
	}
	for(unsigned long int i = 0; i < vec.size(); i++){
		for(unsigned long int j = 0; j < edges.size(); j++){
			if(edges[j][i] != -1){
				test1 = edges[i][j];
				break;
			}
		}
		if(test1 == -1){
			return false;
		}
	}
	return true;

}
void find_path(){
	//find min path from 1 -> 2, 2->3, ...
	//find the value in the map, print the key
	int sum = 0;
	vector<string> key;
	vector<int> num;
	bool path = true;
	map<string, int> ans;
	for(unsigned long int i = 0; i < edges.size()-1; i++){
		int min_edge = 1001;
		int min_row = -1;
		int min_col = -1;
		for(unsigned long int j = 0; j <= i; j++){
			//compare edges[j][i+1]
			if(min_edge > edges[j][i+1] && edges[j][i+1] != -1){
				min_edge = edges[j][i+1];
				min_row = j;
				min_col = i+1;
			}
			if(min_edge == edges[j][i+1]){
				stringstream S1;
				stringstream S2;
				stringstream S3;
				stringstream S4;
				string s0, s1, s3, s4;
				S1 << min_row;
				S1 >> s0;
				S2 << min_col;
				S2 >> s1;
				S3 << i;
				S3 >> s3;
				S4 << j;
				S4 >> s4;
				if(MAP.find(s0+s1)->second > MAP.find(s3+s4)->second){
					min_row = j;
					min_col = i+1;
				}

			}
		}
		if(min_edge == 1001){
			for(unsigned long int y = 0; y < edges.size(); y++){
				if(edges[i][y] < min_edge && edges[i][y] != -1 && edges[i][y] != 0){
					min_edge = edges[i][y];
					min_row = i;
					min_col = y;
				}
			}
			if(min_edge == 1001){
				path = false;
			}
		}
		stringstream S1;
		stringstream S2;
		string s0, s1;
		S1 << min_row;
		S1 >> s0;
		S2 << min_col;
		S2 >> s1;
		key.push_back(s0 + s1);
		num.push_back(min_edge);
		sum += min_edge;
	}
	if(path){
		cout << "Total wire length (meters): " << sum << endl;
		for(unsigned long int i = 0; i < key.size(); i++){
			 ans[MAP.find(key[i])->second] = num[i];
		}
		sort(ans);

		for (auto const& pair: ans) {
			cout << pair.first << " [" << pair.second << "]" <<endl;
		}
	}

	else{
		cout << "No solution.";
	}
}
//convert string to int
int count_f(string str){
	stringstream s(str);
	int count;
	s >> count;
	return count;
}


int main(int argc, const char *argv[]) {
    // Make sure the right number of command line arguments exist.
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <input file>" << endl;
        return 1;
    }
    // Create an ifstream object.
    ifstream input_file(argv[1]);
    // If it does not exist, print an error message.
    if (!input_file) {
        cerr << "Error: Cannot open file '" << argv[1] << "'." << endl;
        return 1;
    }
    // Add read errors to the list of exceptions the ifstream will handle.
    input_file.exceptions(ifstream::badbit);
    string line;
    try {
        unsigned int line_number = 1;
        while (getline(input_file, line)) {
			//Case 1: line 1 must be between 1 and 1000
			istringstream iss(line);
			if(line_number == 1){
				if ( !(iss >> num_v) ) {
					cerr << "Error: Invalid number of vertices '" << line << "' on line 1.";
					return 1;
				}
				if(num_v > 1000 || num_v <= 0) {
					cerr << "Error: Invalid number of vertices '" << line << "' on line 1.";
					return 1;
				}
				if(num_v == 1){
					cout << "No solution.";
					return 1;
				}
				vector<int> sub;
				for(int i = 0; i < num_v ;i++) {
					sub.push_back(-1);
				}
				for(int j = 0; j < num_v ;j++) {
					edges.push_back(sub);
				}
				for(int i = 0; i < num_v; i++) {
					for(int j = 0; j < num_v; j++) {
						if(i == j) {
							edges[i][j] = 0;
						}
					}
				}
			}
            else {
            	int count = 0;
				for(unsigned long int i = 0; i < line.length(); i++){
					if(line[i] == ','){
						count++;
					}
				}
				vector<string> result;
				while(iss.good()){
					string substr;
					getline(iss, substr, ',');
					result.push_back(substr);
				}

				stringstream sfirst;
				stringstream ssecond;
				stringstream sthird;
				int first, second, third;
				for(unsigned long int i = 0; i < result.size(); i++){
					if(i == 0){
						first = count_f(result[0]);
					}
					else if(i == 1){
						second = count_f(result[1]);
					}
					else if(i == 2){
						third = count_f(result[2]);
					}
				}
				stringstream ss;
				ss << num_v;
				string s;
				ss >> s;
				if(count != 3) {
					cerr << "Error: Invalid edge data '" << line << "' on line " << line_number << ".";
					return 1;
				}
				if(first > num_v || first <= 0) {
					cerr << "Error: Starting vertex '" << result[0] << "' on line " << line_number << " is not among valid values 1-" << num_v << ".";
					return 1;
					}
				if(second > num_v || second <= 0) {
					cerr << "Error: Ending vertex '" << result[1] << "' on line " << line_number << " is not among valid values 1-" << num_v << ".";
					return 1;
					}
				if (third <= 0) {
					cerr << "Error: Invalid edge weight '" << result[2] << "' on line " << line_number << ".";
					return 1;
					}
				int index0 = min(first, second)-1;
				int index1 = max(first, second)-1;
				int weight = third;
				stringstream S1;
				stringstream S2;
				string s0, s1;
				S1 << index0;
				S1 >> s0;
				S2 << index1;
				S2 >> s1;
				string key = s0 + s1;
				if(edges[index0][index1] == -1 || edges[index0][index1] > weight){
					edges[index0][index1] = weight;
					MAP[key] = result[3];
				}
            }
			++line_number;
        }

        // Don't forget to close the file.
        input_file.close();
        if(line_number <= 3){
        	cout << "No solution.";
        	return 1;
        }
    } catch (const ifstream::failure &f) {
        cerr << "Error: An I/O error occurred reading '" << argv[1] << "'.";
        return 1;
    }


    find_path();
	return 0;
    }
