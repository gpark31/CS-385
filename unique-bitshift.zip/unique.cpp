/*******************************************************************************
 * Name        : unique.cpp
 * Author      : GaYoung Park
 * Date        : 9/23/2020
 * Description : Determining uniqueness of chars with int as bit vector.
 * Pledge      :I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <iostream>
#include <cctype>
#include <iomanip>

using namespace std;

bool is_all_lowercase(const string &s) {
	istringstream str;
    // TODO: returns true if all characters in string are lowercase
    // letters in the English alphabet; false otherwise.

	for(unsigned int i = 0; i < s.length(); i++){
		if(!islower(s[i])){
			return false;
		}
	}
	return true;
}

bool all_unique_letters(const string &s) {
    // TODO: returns true if all letters in string are unique, that is
    // no duplicates are found; false otherwise.
    // You may use only a single int for storage and work with bitwise
    // and bitshifting operators.
    // No credit will be given for other solutions.
	unsigned int vector = 0;

	for(unsigned int i = 0; i < s.length(); i++){
		unsigned int setter = 1 << (s[i] - 'a');
		if ((setter & vector) == 0){
			vector = setter|vector;
		}
		else{
			return false;
		}
	}
	return true;
}

int main(int argc, char * const argv[]) {
    // TODO: reads and parses command line arguments.
    // Calls other functions to produce correct output.

	//Case 1:
	if(argc <= 1){
		cout << "Usage: ./unique <string>" << endl;
		return 1;
	}

	//Case 2:
	if(argc > 2){
		cout << "Usage: ./unique <string>" << endl;
		return 1;
	}
	//Case 3:
	if(!is_all_lowercase(argv[1])){
		cerr << "Error: String must contain only lowercase letters." << endl;
		return 1;
	}

	//Case 4:
	if(!is_all_lowercase(argv[1])){
		cerr << "Error: String must contain only lowercase letters." << endl;
		return 1;
	}

	else{
	//Case 5:
		if(all_unique_letters(argv[1])){
			cout << "All letters are unique." << endl;
		}
	//Case 6:
		if(!all_unique_letters(argv[1])){
			cout << "Duplicate letters found." << endl;
		}
	}
	return 0;

}
